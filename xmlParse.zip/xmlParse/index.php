<form method="POST" action="<?php echo htmlentities( $_SERVER['PHP_SELF'] ); ?>" >
	
	<input type="text" name="query" value="" placeholder="2.00"/>
	<input type="Submit" value="Search"/>
	
</form>

<?php 

$studentList = simplexml_load_file("studentList.xml");
$sList = array();
if( $_SERVER['REQUEST_METHOD']=="POST" ){
	$q = $_POST['query'];
	
	$i=0;
	foreach( $studentList->Student as $s ){
		if( $s->CGPA==$q ){
			$sList[$i++]=$s;
		}
	}
	if( is_array( $sList ) && sizeof($sList)>0 )
		echo "Match Found:<br>";
	else echo "No Match Found !!<br>";
	foreach( $sList as $key=>$S ){
		
		echo "<h4>Student Name: ".$S->Name."</h4>";
		echo "<h4>ID: ".$S->ID."</h4>";
		echo "<h4>Cgpa: ".$S->CGPA."</h4>";
		
	}

	echo "<hr>";
}

foreach( $studentList->Student as $S ){
	
	echo "<h4>Student Name: ".$S->Name."</h4>";
	echo "<h4>ID: ".$S->ID."</h4>";
	echo "<h4>Cgpa: ".$S->CGPA."</h4>";
	
	echo "<h4><u>Courses Taken: </u></h4>"."";
	$i=0;
	foreach( $S->Courses->Course as $C ){
		echo "<li>".++$i.". ".$C->name." | Section: ".$C->section." | Grade: ".$C->grade."</li>";
	}
	
	echo "<hr>";
}

?>